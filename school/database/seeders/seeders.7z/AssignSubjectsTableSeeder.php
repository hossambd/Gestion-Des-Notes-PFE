<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Helpers\Qs;
use Illuminate\Support\Str;

class AssignSubjectsTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DB::table('assign_subjects')->truncate();

        $this->createManyAssignSubjects(16);
    }

    protected function createManyAssignSubjects(int $count)
    {
        $data = [];$j=1;
        for($i = 1; $i <= $count; $i++){
			while($j <= 3*$i)
			{   $data[] = [
				    'class_id' => $i,
					'subject_id' => $j,
					'full_mark' => 20,
					'pass_mark' => 10,
					'subjective_mark' => 7,
					'coef_mark' => 2,
                ];
			$j++;
            }

        }

        DB::table('assign_subjects')->insert($data);
    }
}
