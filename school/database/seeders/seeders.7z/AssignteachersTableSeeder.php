<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Helpers\Qs;
use Illuminate\Support\Str;

class AssignTeachersTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DB::table('assign_teachers')->truncate();

        $this->createAssignTeachers();
    }

    protected function createAssignTeachers()
    {
      
			   $data =[
			   [
				    'teacher_id' => 3,
					'subject_id' => 1,
                ],
				[
				    'teacher_id' => 3,
					'subject_id' => 4,
                ],
				[
				    'teacher_id' => 3,
					'subject_id' => 13,
                ],
				[
				    'teacher_id' => 3,
					'subject_id' => 16,
                ],
				[
				    'teacher_id' => 4,
					'subject_id' => 2,
                ],
				[
				    'teacher_id' => 4,
					'subject_id' => 5,
                ],
				[
				    'teacher_id' => 4,
					'subject_id' => 14,
                ],
				[
				    'teacher_id' => 4,
					'subject_id' => 17,
                ],
				];

        DB::table('assign_teachers')->insert($data);
    }
}
