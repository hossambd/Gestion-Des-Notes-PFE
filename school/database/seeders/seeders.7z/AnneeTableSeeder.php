<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Helpers\Qs;
use Illuminate\Support\Str;

class AnneesTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DB::table('annees')->truncate();

        $this->createStudentShifts();
    }

    protected function createStudentShifts()
    {
       
                $data= [
				[
				    'name' => '2020-2021',
                ],
				[
					'name' => '2021-2022',
				],
				];

            

        

        DB::table('annees')->insert($data);
    }
}
