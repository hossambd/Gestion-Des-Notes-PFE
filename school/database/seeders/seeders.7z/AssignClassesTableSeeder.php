<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Helpers\Qs;
use Illuminate\Support\Str;

class AssignClassesTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DB::table('assign_classes')->truncate();

        $this->createManyAssignclasses(4);
    }

    protected function createManyAssignclasses(int $count)
    {
        $data = [];$j=1;
        for($i = 1; $i <= $count; $i++){
			while($j <= $count*$i)
			{   $data[] = [
				    'year_id' => $i,
					'class_id' => $j,
                ];
			$j++;
            }

        }

        DB::table('assign_classes')->insert($data);
    }
}
