<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Helpers\Qs;
use Illuminate\Support\Str;

class AssignStudentsTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DB::table('assign_students')->truncate();
      for($i = 1; $i <= 2; $i++)
	  {$this->createAssignStudents(1,4+$i);}
    }

    protected function createAssignStudents($sem,$id)
    {
           $data = [];$j=1;
            for($i = 1; $i <= 4; $i++){
			while($j <= 3*$i)
			{   $data[] = [
				    'student_id' => $id,
					'year_id' => $sem,
					'class_id'=> $i,
					'subject_id' => $j,
				];
				$j++;
			}
			}
        DB::table('assign_students')->insert($data);
    }
}
