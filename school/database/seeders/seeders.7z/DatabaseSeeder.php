<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
		   $this->call(UsersTableSeeder::class);
			$this->call(SemestresTableSeeder::class);
			$this->call(ModulesTableSeeder::class);
			$this->call(ElementsTableSeeder::class);
			$this->call(StudentShiftsTableSeeder::class);
			$this->call(GroupeTableSeeder::class);
			$this->call(ExamTypesTableSeeder::class);
		  $this->call(AssignClassesTableSeeder::class);
			$this->call(AssignSubjectsTableSeeder::class);   
	      $this->call(AssignTeachersTableSeeder::class);
		$this->call(AssignStudentsTableSeeder::class);
		
        // \App\Models\User::factory(10)->create();
    }
}
