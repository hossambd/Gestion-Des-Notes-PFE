<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Helpers\Qs;
use Illuminate\Support\Str;

class ElementsTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DB::table('elements')->truncate();
       // DB::table('modules')->delete();

        $this->createManySchoolSubjects(24);
    }

    protected function createManySchoolSubjects(int $count)
    {
        $data = [];
        for($i = 1; $i <= $count; $i++){
                $data[] = [
				    'name' => 'Élement '.$i,
                ];

            

        }

        DB::table('elements')->insert($data);
    }
}
